/*
Authors : Flavien Pechere
          Hadrien Vinay
          Arnaud Goguel

          With the help of our group GameController
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#define SIZE 8

//struct for block's game
struct slot
{
    int x;
    int y;
    int state; //0:vide  --  1:noir -- 2:blanc
    struct slot *next;
};


//struct of plot
struct slot *matrice[SIZE][SIZE];
//tab to receive the message from the server
int gridBlock[64];
//tab who receive the hex server messages
int tab_hex[(SIZE*SIZE)/4];

//init our blocks
void initslot()
{
    int i,j;
    struct slot *newslot,*nextslot;
    newslot = (struct slot *)malloc(sizeof(struct slot));
    nextslot = (struct slot *)malloc(sizeof(struct slot));

    for(i=0; i<SIZE; i++)
    {
        for(j=0; j<SIZE; j++)
        {
            newslot->next=NULL;
            newslot->x=i;
            newslot->y=j;
            newslot->state=0;

            //init of black case
            if((i==SIZE/2-1 && j==SIZE/2-1) || (i==SIZE/2 && j==SIZE/2))
            {
                newslot->state=2;
            }
            //init of white case
            else if((i==SIZE/2 && j==SIZE/2-1) || (i==SIZE/2-1 && j==SIZE/2))
            {
                newslot->state=1;
                //newslot->slot=chargerImage("images/black.bmp");
            }
            //else other case are empty
            else
            {
                newslot->state=0;
            }
            matrice[i][j]=newslot;
            //printf("%d\n",matrice[i][j]->state);
            newslot->next = (struct slot *)malloc(sizeof(struct slot));
            newslot = newslot->next;
        }
    }
}

//create our grid
void creationGrille()
{
    int i,j;
    char num = '0';
    char car='0';

    for(i=-1; i<SIZE; i++)
    {
        for(j=-1; j<SIZE; j++)
        {
            if(i==-1 && j==-1)
            {
                printf(" ");
            }
            else if(i==-1)
            {
                printf("%c",car);
                car++;
            }
            else if(j==-1)
            {
                printf("%c",num);
                num++;
            }
            else
            {
                printf("%d",matrice[i][j]->state);
            }
            printf(" ");
        }
        printf("\n");
    }

}

// Receive message from the server
int read_message(int sock, char tab3[100])
{
    int choix = 0;
    int i;
    int matrice_size_x = tab3[5];
    int matrice_size_y = tab3[6];
    int matrice[matrice_size_x*matrice_size_y]; // JUSTE THERE TO BE DISPLAYED TO HELP THE PLAYER TO CHOOSE
    // ERROR MESSAGE IF FAILURE TO READ CORRECTLY
    if( read(sock , tab3 , 100 ) < 0) // read message
    {
        puts("read failed. ");
        perror ("Error");
        return choix;
    }

    {
        ///Ok Message type return black or white guy
        if (tab3[2] == 0x10)
        {
            puts("OK message received : 0x10\n");
            if (tab3[3] == 0x01) puts("You play as the BLACK Player.\n");//black guy
            if (tab3[3] == 0x02) puts("You play as the WHITE Player.\n");//white guy
            choix = 1;
        }
        ///Ok-NOK Message type
        if (tab3[2] == 0x02)
        {
            if (tab3[3] == 0x01)
            {
                puts("Ok message received : 0x02/0x01....\n ");
            }
            else if (tab3[3] == 0x00)
            {
                puts("NON-Ok message received : 0x02/0x00 \n");
            }
            choix = 2;
        }
        /// Next Turn message : read the board status.
        if (tab3[2] == 0x05)// Next Turn message
        {
            ///Next turn : 0x05, LastmoveX, LastmoveY, BoardsizeX, BoardsizeY, boardState.....boardStateN
            puts ("NEXT TURN message received : 0x05.....");
            puts (" DECODING the HEXA BOARD STATE : ");

            ///CONVERSION FROM HEXA TO BITS
            for(i=0; i<16; i++)
            {
                tab_hex[i]=tab3[7+i]; // get the hex matrix cases tab[7] to tab[23]
            }
            receiveMessage(); //update our matrix


            printf("DISPLAY OF THE GRID  : \n");
            printf("BOARD SIZE X : %d - BOARD SIZE Y : %d \n", tab3[5], tab3[6]);

            creationGrille();
            printf("\n\n\n\n\n\n");

            choix = 3;
        }
        ///Ping Message type return a ok message to validate the connection
        if (tab3[2] == 0x11)
        {
            puts("PING message received : 0x11\n");
            choix = 4;
        }

        ///End Message type : the client must disconnect
        if (tab3[2] == 0x04)
        {
            puts("End message received : 0x04\n Please Disconnect...................\n");
            choix = 5;
            close (sock);
            exit(0);
        }

        ///Control Message type : mode choice
        if (tab3[2] == 0x08)
        {
            puts("Control message received : 0x08\n");
            if (tab3[6]== 0x00)//Game mode : step by step
            {
                printf("GAME MODE : STEP by STEP....\n");
                choix = 6;
            }
            else if(tab3[6]==0x01)//Game mode : Continuous (IA)
            {
                printf("GAME MODE : CONTINUOUS (IA). WATCH AND LEARN FROM OUR ALGO :)\n");
                choix = 7;
            }
        }
        puts("puts Server reply : ");
        puts(tab3);
    }
    return choix;
}

//send ok message to the server
void ok_message(int sock, char tab[100])
{
// Send an OK message
    tab[1] = 1 ;//message + name length
    tab[2] = 0x02; //OK -NONOK
    tab[3] = 0x01;//Name length : Player --> 7
    tab[4] = 0x00;//Checksum
    if( write(sock, tab, strlen(tab)) < 0) // negatif if fail
    {
        puts("write failed");
    }
    else printf("OK message sent to test the connection");
}

// on renvoie un tableau de type connect
void connect_message(char tab[100], char tab2[100])
{
    int pseudo_size = 0;
    printf("Enter your game's PSEUDO : ");
    scanf("%s", tab2);
    pseudo_size = strlen(tab2);
    tab[2] = 0x01; //message CONNECT-type
    tab[1] = strlen(tab2)+1;//message + name length
    tab[3] = strlen(tab2);//Name length : Player --> 6
    for (int a = 0; a<pseudo_size; a++)
    {
        tab[a+4] = tab2[a];
    }
    tab[strlen(tab)] = 0x00;//Checksum
}

void new_move(int sock, char tab[100], int x,int y) // We send the new move
{
    tab[1] = 2 ;//message size
    tab[2] = 0x03; //NEW MOVE TYPEtype
    tab[3] = '0'+ x ;//X coordinates
    tab[4] = '0'+ y ;//Y coordinates
    tab[5] = 0x00;//Checksum

    if( write(sock, tab, strlen(tab)) < 0) // negatif if fail
    {
        puts("write failed");
    }
    printf("New move" "(" "%d,%d" ")"  "sent to the server...\n",x,y);
    printf("Waiting for a Ok/Nok approval message..... ");
}

//receive message and displau activities from the server
void boucle_de_jeu(int sock, char tab[100], char tab2[100])
{
    int pos_x = 0;
    int pos_y = 0;

    read_message(sock,tab2);
    /****** Wait for Next turn Message****/
    if(read_message(sock,tab2)!=3)
    {
        printf("Waiting for Next Turn message......\n");
    }
    creationGrille();
    puts("It is your turn to play !");
    printf("coordonnates in X : "); // type the coordonates in X
    scanf("%d",&pos_x); //store the number as an int
    printf("coordonnates in Y : "); // type the coordonates in Y
    scanf("%d",&pos_y); // store the number as an int
    new_move(sock,tab,pos_x,pos_y);
    read_message(sock, tab2);

}

//connection test with the server
void initServer()
{
    int sock;
    struct sockaddr_in server;
    char message[1000] , server_reply[2000];
//Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");
    server.sin_addr.s_addr =  inet_addr("127.0.0.1");
    server.sin_family =  AF_INET;
    server.sin_port = htons(8888);
    if(connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("connect failed. Error");
        printf("%d",server.sin_addr);
        return 1;
    }
    puts("Connected\n");
    while(1)
    {
        printf("Enter message : ");
        scanf("%s" , message);
//Send some data
        if( write(sock , message , strlen(message) , 0) < 0)
        {
            puts("write failed");
            return 1;
        }

//Receive a reply from the server
        if( read(sock , server_reply , 2000 ) < 0)
        {
            puts("read failed");
            break;
        }
        puts("Server reply :");
        puts(server_reply);
    }
    close(sock);
    return 0;

}


//update 4block in the grid with one byte
void updateGrid(int number,int loop)
{
    int i,j;
    int case1,case2,case3,case4;//create four cases
    case1 = number & 0b11000000;//first case
    case2 = number & 0b00110000;//second case
    case3 = number & 0b00001100;//third case
    case4 = number & 0b00000011;//fourth case

    switch(case1)//convert each case : 0 for empty(00), 1 for black(01), 2 for white(10)
    {
    case 0b11000000:
        case1=0b00000011;
        break;
    case 0b10000000:
        case1=0b00000010;
        break;
    case 0b01000000:
        case1=0b00000001;
        break;
    case 0b00000000:
        case1=0b00000000;
        break;
    }

    switch(case2)
    {
    case 0b00110000:
        case2=0b00000011;
        break;
    case 0b00100000:
        case2=0b00000010;
        break;
    case 0b00010000:
        case2=0b00000001;
        break;
    case 0b00000000:
        case2=0b00000000;
        break;
    }

    switch(case3)
    {
    case 0b00001100:
        case3=0b00000011;
        break;
    case 0b00001000:
        case3=0b00000010;
        break;
    case 0b00000100:
        case3=0b00000001;
        break;
    case 0b00000000:
        case3=0b00000000;
        break;
    }
    //insert them in a tab[]
    gridBlock[loop]=case1;
    gridBlock[loop+1]=case2;
    gridBlock[loop+2]=case3;
    gridBlock[loop+3]=case4;

    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            printf("%d ",gridBlock[loop]);
            loop++;
        }
    }


}


//convert the messages of the server and update our matrix
void receiveMessage()
{

    int i,j;
    int loop=0;
//connect to server

    //send ok and receive matrix and update matrix and display it
    for(i=0; i<16; i++)
    {
        updateGrid(tab_hex[i],loop);
        loop=loop+4;
    }

    for(i=0; i<SIZE; i++)
    {
        for(j=0; j<SIZE; j++)
        {
            int indice=i*SIZE+j;
            matrice[i][j]->state=gridBlock[indice];
        }
    }

    // send next move 0x05


}

int main(int argc , char *argv[])
{
    //create our matrice and connect to server
    initslot();

    int sock;
    struct sockaddr_in server;
    char message[100], message2 [100], server_reply[100];
//Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");

// Define the Socket remote adress : 127.0.0.1:8888
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(8888);

// Connect to remote server. open WP or BP port as client.
    if(connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("connect failed. Error");
        return 1;
    }
    puts("CONNECTED\n");

    message[0] = 0x55;//Synchro
// send connect message
    connect_message(message,message2);
    puts("CONNECT message sent to the server............");
    puts("Waiting for a control message with the right Game mode : Continuous (0x00) or Step-by-step (0x01)........ ");

    while(1)
    {
        if( write(sock, message, strlen(message)) < 0) // neg if failure
        {
            puts("write failed");
            return 1;
        }
        // Wait for the server's answer
        puts("Waiting for server's response ..........");

        boucle_de_jeu(sock, message,server_reply);
    }
    printf("boucle_de_jeu finie \n\n\n\n");


    puts("DISCONNECTED");
    close(sock);
}
